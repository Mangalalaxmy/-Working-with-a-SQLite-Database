import math
import sqlite3
import pandas as pd
conn = sqlite3.connect("factbook.db")
df = pd.read_sql_query("select * from facts", conn)
df = df.dropna(axis=0)

def final_p(row):
    p = row["population"]
    pg = row["population_growth"]
    return int( p * (math.e ** (pg/100)*35))
      
 
df["final_population_2050"] = df.apply(lambda row: final_p(row), axis=1)   
df.sort_values("final_population_2050", ascending=False)

print(df[["name", "final_population_2050"]].head(10))

        