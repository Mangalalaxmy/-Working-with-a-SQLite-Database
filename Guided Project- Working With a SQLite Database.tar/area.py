import sqlite3
import pandas as pd
conn = sqlite3.connect("factbook.db")
total_land = pd.read_sql_query("select sum(area_land) from facts", conn)
total_water = pd.read_sql_query("select sum(area_water) from facts", conn)
prop = pd.read_sql_query("select area_land/area_water from facts", conn)

print(total_land)
print(total_water)
print(prop)



