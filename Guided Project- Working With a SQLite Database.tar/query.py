import sqlite3
conn = sqlite3.connect("factbook.db")
a = conn.cursor()
a.execute("select name from facts order by population asc limit 10;")
print(a.fetchall())
